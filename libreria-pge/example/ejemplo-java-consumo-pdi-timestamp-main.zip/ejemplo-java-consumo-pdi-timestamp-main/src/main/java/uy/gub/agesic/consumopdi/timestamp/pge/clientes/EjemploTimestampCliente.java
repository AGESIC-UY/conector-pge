package uy.gub.agesic.consumopdi.timestamp.pge.clientes;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMFactory;
import org.apache.axiom.om.OMNamespace;
import org.apache.axis2.Constants;
import org.apache.axis2.Constants.Configuration;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.Options;
import org.apache.axis2.client.ServiceClient;
import org.apache.axis2.kernel.http.HTTPConstants;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uy.gub.agesic.consumopdi.timestamp.pge.ClienteTimestampException;
import uy.gub.agesic.consumopdi.timestamp.pge.config.Config;
import uy.gub.agesic.consumopdi.timestamp.pge.config.PGEFacilitator;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.*;

public class EjemploTimestampCliente {

	public static final String EJEMPLO_TIMESTAMP = "ejemplo-timestamp";
	private static Logger logger = LoggerFactory.getLogger(EjemploTimestampCliente.class);

	private final PGEFacilitator pgeFacilitaror;

	public EjemploTimestampCliente(PGEFacilitator pgeFacilitaror){
		this.pgeFacilitaror = pgeFacilitaror;
	}

	private void addClientCertificate(ServiceClient sender) throws FileNotFoundException, KeyStoreException, NoSuchAlgorithmException, UnrecoverableKeyException, KeyManagementException {
		CloseableHttpClient httpClient;
		if(Boolean.parseBoolean(Config.getValuePGE(Config.ENABLED))) {
			TrustManagerFactory trustManagerFactory = pgeFacilitaror.getTrustManagerFactory(
					Config.getValuePGE(Config.SSL_TRUSTSTORE_FILEPATH), Config.getValuePGE(Config.SSL_TRUSTSTORE_PASS));

			KeyManagerFactory keyManagerFactory = pgeFacilitaror.getKeyManagerFactory(
					Config.getValuePGE(Config.SSL_CLIENT_KEYSTORE_FILEPATH),
					Config.getValuePGE(Config.SSL_CLIENT_KEYSTORE_PASS));

			SSLContext sslContext = SSLContext.getInstance("TLS");
			sslContext.init(keyManagerFactory.getKeyManagers(), trustManagerFactory.getTrustManagers(), new SecureRandom());

			httpClient = PGEFacilitator.getCloseableHttpClient(sslContext);
		} else {
			httpClient = HttpClients.createDefault();
		}

		Options options = new Options();
		String urlServicio = Config.getValuePGE(EJEMPLO_TIMESTAMP, Config.WS_URL);
		options.setTo(new EndpointReference(urlServicio));
		options.setProperty(Configuration.ENABLE_MTOM, Constants.VALUE_TRUE);

		if(urlServicio.toLowerCase().startsWith("https:")) {
			options.setTransportInProtocol(Constants.TRANSPORT_HTTPS);
		} else {
			options.setTransportInProtocol(Constants.TRANSPORT_HTTP);
		}
		Integer timeout = Integer.parseInt(Config.getValuePGE(Config.TIMEOUT),10);
		options.setTimeOutInMilliSeconds(timeout);
		options.setProperty(HTTPConstants.SO_TIMEOUT, timeout);
		options.setProperty(HTTPConstants.CONNECTION_TIMEOUT, timeout);
		options.setProperty(Configuration.MTOM_THRESHOLD, 0);
		options.setProperty(HTTPConstants.CACHED_HTTP_CLIENT, httpClient);

		// las opciones anteriores son globales, esta debe definirse según la operación que se está llamando,
		// podría ponerse en un método particular que haga todo lo necesario para poder invocar una determinada operación
		options.setAction(Config.getValuePGE(EJEMPLO_TIMESTAMP, Config.WS_WSA_ACTION));
		sender.setOptions(options);

	}

	private OMElement getSoapMessageEjemploTimestamp(ServiceClient sender) throws Exception {
		logger.debug("Preparando invocación servicio Ejemplo-Timestamp");

		if(Boolean.parseBoolean(Config.getValuePGE(Config.ENABLED))) {
			pgeFacilitaror.addWSSecurity(sender, EJEMPLO_TIMESTAMP);
			logger.debug("se agregó header seguridad");

		}
		addClientCertificate(sender);
		logger.debug("se agregó certificado para mutual ssl");
		OMFactory fac = OMAbstractFactory.getOMFactory();
		//se crea namespace del servicio
		OMNamespace omNs = fac.createOMNamespace("http://www.agesic.gub.uy/soa", "soa");

		return addPayloadInSoapBody(fac, omNs);
	}

	/*
		se arma el body del soap, en este caso solo contiene un archivo.
	 */
	private static OMElement addPayloadInSoapBody(OMFactory fac, OMNamespace omNs) throws IOException {

		return  fac.createOMElement("GetTimestamp", omNs);
	}

	public void ejecutar() {
		try {
			ServiceClient sender = new ServiceClient();

			OMElement payload = getSoapMessageEjemploTimestamp(sender);
			if(logger.isInfoEnabled()) {
				logger.info(payload.toStringWithConsume());
			}
			OMElement result = sender.sendReceive(payload);

			// se busca en forma genérica el nodo xml correspondiente al código de respuesta. En caso de ser exitosa la operación
			// será OK
			String response = result.getFirstElement().getText();
			if(logger.isInfoEnabled()) {
				logger.info(String.format("SOAP Timestamp, respuesta: %s", response));
			}
		} catch (Exception aE) {
			throw new ClienteTimestampException(aE);
		}
	}
}