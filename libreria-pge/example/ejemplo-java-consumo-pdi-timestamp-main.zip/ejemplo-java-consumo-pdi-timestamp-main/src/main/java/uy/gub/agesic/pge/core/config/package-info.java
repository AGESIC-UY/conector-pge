package uy.gub.agesic.pge.core.config;

