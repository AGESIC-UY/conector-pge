package uy.gub.agesic.consumopdi.timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import uy.gub.agesic.consumopdi.timestamp.pge.ClienteTimestampException;
import uy.gub.agesic.consumopdi.timestamp.pge.clientes.EjemploTimestampCliente;
import uy.gub.agesic.consumopdi.timestamp.pge.config.Config;
import uy.gub.agesic.consumopdi.timestamp.pge.config.PGEFacilitator;

import java.util.Objects;

@SpringBootApplication
public class TimestampServiceClientApplication implements CommandLineRunner {

	private static Logger logger = LoggerFactory.getLogger(TimestampServiceClientApplication.class);

	private static PGEFacilitator pgeFacilitaror;


	public static void main(String[] args) {

		Config.loadConfigPGE();

		//System.setProperty("javax.net.debug","ssl:handshake:verbose"); //Descomentar para ver errores de handshake

		logger.info("Propiedades cargadas");
		SpringApplication.run(TimestampServiceClientApplication.class, args);
		logger.info("Aplicación levantada");
	}


	static {
		String path = Objects.requireNonNull(TimestampServiceClientApplication.class.getClassLoader()
						.getResource("logging.properties"))
				.getFile();
		System.setProperty("java.util.logging.config.file", path);
		logger = LoggerFactory.getLogger(TimestampServiceClientApplication.class.getName());

		pgeFacilitaror = new PGEFacilitator();

	}

	@Override
	public void run(String... args) {
		logger.info("Ejecutando commando");
		try {
			var cliente = new EjemploTimestampCliente(pgeFacilitaror);
			cliente.ejecutar();
		} catch (Exception aE) {
			throw new ClienteTimestampException(aE);
		}
	}
}