package uy.gub.agesic.consumopdi.timestamp.pge.config;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ClientTimestampConfig {
    private String wsaTo;
    private String wsaAction;
    private String stsURL;
    private String stsIssuer;
    private String stsPolicyName;
    private String stsRole;
    private String stsUserName;
    private String samlVersion;
    private Boolean cacheTokenEnabled;
    private String soapVersion;
    private String stsKeyStoreFilePath;
    private String stsKeyStorePass;
    private String stsKeyStoreCertAlias;
    private String sslTrustStoreFilePath;
    private String sslTrustStorePass;
    private Integer maxTotalOpenConnections;
    private Integer maxConnectionsPerRoute;
    private Integer maxConnectionsHostnamePort;
}
