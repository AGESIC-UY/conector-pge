package uy.gub.agesic.consumopdi.timestamp.pge;

public class ClienteTimestampException extends RuntimeException {
    public ClienteTimestampException(Exception ex) {
        super(ex);
    }
}
