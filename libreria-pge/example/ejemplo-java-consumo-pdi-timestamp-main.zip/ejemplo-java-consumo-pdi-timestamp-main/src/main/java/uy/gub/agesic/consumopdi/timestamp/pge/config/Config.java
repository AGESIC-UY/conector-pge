package uy.gub.agesic.consumopdi.timestamp.pge.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class Config {

	private Config() {

	}

	static Logger logger = LoggerFactory.getLogger(Config.class);

	static Properties propPGE = new Properties();
	static Properties propLocalidades = new Properties();

	public static final String PROXY_USE = "proxy.use";
	public static final String PROXY_HOST = "proxy.host";
	public static final String PROXY_PORT = "proxy.port";

	public static final String DEBUG_LOG_FILE = "debug.log_file";
	public static final String DEBUG_LOG_LEVEL = "debug.log_level";
	public static final String NAME_LOGGER = "debug.name_logger";
	public static final String LOG_TO_CONSOLE = "debug.log_to_console";
	public static final String LOG_DIRECTORY = "debug.log_directory";
	public static final String LOG_SHOW_TIME = "debug.log_show_time";

	public static final String TIMEOUT = "timeout";
	public static final String WS_WSA_TO = "wsa_to";
	public static final String WS_WSA_ACTION = "wsa_action";
	public static final String WS_URL = "url";
	public static final String WS_SERVICE = "service";
	public static final String WS_STS_ROLE = "sts.role";
	public static final String WS_STS_USERNAME = "sts.username";

	public static final String SAML_VERSION = "conectorpge.sts.saml.version";
	public static final String SOAP_VERSION = "conectorpge.sts.soap.version";
	public static final String CACHE_TOKEN_ENABLED = "conectorpge.sts.cache_token_enabled";

	public static final String MAX_CONNECTIONS_PER_ROUTE = "conectorpge.saml.max_connections_per_route";
	public static final String MAX_CONNECTIONS_HOSTNAME_PORT = "conectorpge.saml.max_connections_hostname_port";
	public static final String MAX_TOTAL_OPEN_CONNECTIONS = "conectorpge.saml.max_total_open_connections";

	public static final String SAML_PROPERTY = "conectorpge.saml_property";

	public static final String STS_URL = "conectorpge.sts.url";
	public static final String STS_ISSUER = "conectorpge.sts.issuer";
	public static final String STS_POLICY_NAME = "conectorpge.sts.policy_name";
	public static final String STS_ROLE = "conectorpge.sts.role";
	public static final String STS_USERNAME = "conectorpge.sts.username";
	public static final String STS_SERVICE = "conectorpge.sts.service";
	public static final String STS_SECURITY_ACTOR = "conectorpge.sts.security_actor";

	public static final String STS_KEYSTORE_FILEPATH = "conectorpge.sts.keystore.filepath";
	public static final String STS_KEYSTORE_PASS = "conectorpge.sts.keystore.pass";
	public static final String STS_KEYSTORE_ALIAS = "conectorpge.sts.keystore.alias";

	public static final String SSL_CLIENT_KEYSTORE_FILEPATH = "conectorpge.ssl_client_keystore.filepath";
	public static final String SSL_CLIENT_KEYSTORE_PASS = "conectorpge.ssl_client_keystore.pass";
	public static final String SSL_CLIENT_KEYSTORE_ALIAS = "conectorpge.ssl_client_keystore.alias";

	public static final String SSL_TRUSTSTORE_PASS = "conectorpge.ssl_truststore.pass";

	public static final String ENABLED = "conectorpge.enabled";
	public static final String SSL_TRUSTSTORE_FILEPATH = "conectorpge.ssl_truststore.filepath";
	public static final String OPTIONAL_SECURITY_URLS = "optional_security.urls";

	public static final String FILE_NAME_PGE = "conector-pge.properties";

	private static Date lastDateTimeReadPGE = null;

	public static void loadConfigPGE() {
		lastDateTimeReadPGE = loadConfigInternal(propPGE, FILE_NAME_PGE, lastDateTimeReadPGE);
	}


	public static final String getValuePGE(String prefix, String propertyName) {
		return getValue(propPGE, prefix + "." + propertyName, "PGE");
	}

	public static final String getValuePGE(String propertyName) {
		return getValue(propPGE, propertyName, "PGE");
	}

	public static List<String> getValuesPGE(String propertyName) {
		return getValues(propPGE, propertyName, "PGE");
	}


	private static Date loadConfigInternal(Properties prop, String configFileName, Date lastDate) {
		Date today = new Date();

		try {

			logger.info("Cargando configuración.");
			loadProperties(prop, configFileName);
			return today;
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return lastDate;
	}

	private static void loadProperties(final Properties prop, final String configFileName) throws IOException {

		Path currentRelativePath = Paths.get(configFileName);
		try (InputStream input = new FileInputStream(currentRelativePath.toAbsolutePath().toString())) {
			//load a properties file from class path, inside static method
			prop.load(input);
		}
	}

	private static String getValue(Properties prop, String propertyName, String configName) {
		String value = null;
		try {
			value = prop.getProperty(propertyName);
			if(logger.isDebugEnabled()) {
				logger.debug(String.format("%s propiedad '%s', valor: %s", configName, propertyName, value));
			}
		} catch (Exception ex) {
			if(logger.isDebugEnabled()) {
				logger.debug(String.format("%s propiedad '%s', valor: null", configName, propertyName));
			}
		}

		return value;
	}

	private static List<String> getValues(Properties prop, String propertyName, String configName) {
		String value = null;
		List<String> list = new ArrayList<>();
		for (Object oKey : prop.keySet()) {
			if (((String) oKey).startsWith(propertyName + "[")) {
				try {
					value = prop.getProperty((String) oKey);
					if(logger.isDebugEnabled()) {
						logger.debug(String.format("%s propiedad '%s', valor: %s", configName, propertyName, value));
					}
				} catch (Exception ex) {
					if(logger.isDebugEnabled()) {
						logger.debug(String.format("%s propiedad '%s', valor: null", configName, propertyName));
					}
				}
				list.add(value);
			}
		}
		return list;
	}
}
