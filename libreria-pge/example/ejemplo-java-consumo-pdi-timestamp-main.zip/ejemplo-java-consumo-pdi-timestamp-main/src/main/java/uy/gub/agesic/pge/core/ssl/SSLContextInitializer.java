package uy.gub.agesic.pge.core.ssl;

import uy.gub.agesic.pge.core.config.PGEConfiguration;

import javax.xml.ws.Dispatch;

public interface SSLContextInitializer {
  void initSSLContext(Dispatch<?> paramDispatch, PGEConfiguration paramPGEConfiguration);

  void initSSLContextPort(Object paramObject, PGEConfiguration paramPGEConfiguration);
}