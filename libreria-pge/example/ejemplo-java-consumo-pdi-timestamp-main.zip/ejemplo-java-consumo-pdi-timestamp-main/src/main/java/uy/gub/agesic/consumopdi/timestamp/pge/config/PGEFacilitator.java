package uy.gub.agesic.consumopdi.timestamp.pge.config;

import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.util.AXIOMUtil;
import org.apache.axis2.client.ServiceClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.config.SocketConfig;
import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.ls.DOMImplementationLS;
import org.xml.sax.InputSource;
import uy.gub.agesic.pge.beans.STSResponse;
import uy.gub.agesic.pge.client.PGEClient;
import uy.gub.agesic.pge.client.PGEClientBasic;
import uy.gub.agesic.pge.client.PGEClientCache;
import uy.gub.agesic.pge.core.config.ConfigProperties;
import uy.gub.agesic.pge.core.config.PGEConfig;
import uy.gub.agesic.pge.core.config.PGEConfiguration;
import uy.gub.agesic.pge.exceptions.ConfigurationException;
import uy.gub.agesic.pge.exceptions.PGEContextException;
import uy.gub.agesic.pge.exceptions.RequestSecurityTokenException;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.stream.XMLStreamException;
import java.io.*;
import java.security.*;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.List;

public class PGEFacilitator {
	Logger logger = LoggerFactory.getLogger(PGEFacilitator.class);
	private static final String WS_ADDRESSING_ACTION_PART_FORMAT	= "<wsa:Action xmlns:wsa='http://www.w3.org/2005/08/addressing'>%s</wsa:Action>";
	private static final String WS_ADDRESSING_TO_PART_FORMAT	= "<wsa:To xmlns:wsa='http://www.w3.org/2005/08/addressing'>%s</wsa:To>";
	private static final String WS_SECURED_HEADER_PART = "<header><wsse:Security  xmlns:wsse='http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd'></wsse:Security></header>";
	
	public void addWSSecurity(ServiceClient sender, String servicio) throws PGEContextException, XMLStreamException {
		String wsaTo = Config.getValuePGE(servicio, Config.WS_WSA_TO);
		String wsaAction = Config.getValuePGE(servicio, Config.WS_WSA_ACTION);
		String stsService = Config.getValuePGE(servicio, Config.WS_SERVICE);

		Element assertion = getWSSecurity(servicio, wsaTo, wsaAction, stsService);
		if (assertion == null ) {
			throw  new PGEContextException("No fue posible obtener un SAML assertion");
		}
		for (int i = 0; i < assertion.getChildNodes().getLength(); i++) {
			Element e = (Element) assertion.getChildNodes().item(i);
			OMElement ome = AXIOMUtil.stringToOM(((DOMImplementationLS)assertion.getOwnerDocument().getImplementation()).createLSSerializer().writeToString(e));
			sender.addHeader(ome);
		}
	}
	
	private Element getWSSecurity(String servicio, String wsaTo, String wsaAction, String stsService) {

		logger.debug("+++++++++++++++++Comenzando firma SOAP ++++++++++++++++++");
		
		if (wsaTo == null || wsaAction == null || stsService == null) {
			return null;
		}
	
		String stsURL = Config.getValuePGE(Config.STS_URL);
		String stsIssuer = Config.getValuePGE(Config.STS_ISSUER);
		String stsPolicyName = Config.getValuePGE(Config.STS_POLICY_NAME);
		String stsRole = Config.getValuePGE(servicio + "."+ Config.WS_STS_ROLE);
		if(stsRole == null || stsRole.equals(""))
			stsRole = Config.getValuePGE(Config.STS_ROLE);
		String stsUserName = Config.getValuePGE(servicio + "."+ Config.WS_STS_USERNAME);
		if(stsUserName == null || stsUserName.equals(""))
			stsUserName = Config.getValuePGE(Config.STS_USERNAME);


		String samlVersion = Config.getValuePGE(Config.SAML_VERSION);

		Boolean cacheTokenEnabled = Boolean.valueOf(Config.getValuePGE(Config.CACHE_TOKEN_ENABLED));

		String soapVersion = Config.getValuePGE(Config.SOAP_VERSION);

		String stsKeyStoreFilePath = Config.getValuePGE(Config.STS_KEYSTORE_FILEPATH);
		String stsKeyStorePass = Config.getValuePGE(Config.STS_KEYSTORE_PASS);
		String stsKeyStoreCertAlias = Config.getValuePGE(Config.STS_KEYSTORE_ALIAS);

		String sslTrustStorePass = Config.getValuePGE(Config.SSL_TRUSTSTORE_PASS);
		String sslTrustStoreFilePath = Config.getValuePGE(Config.SSL_TRUSTSTORE_FILEPATH);
		Integer maxTotalOpenConnections = Integer.parseInt(Config.getValuePGE(Config.MAX_TOTAL_OPEN_CONNECTIONS));
		Integer maxConnectionsPerRoute = Integer.parseInt(Config.getValuePGE(Config.MAX_CONNECTIONS_PER_ROUTE));
		Integer maxConnectionsHostnamePort = Integer.parseInt(Config.getValuePGE(Config.MAX_CONNECTIONS_HOSTNAME_PORT));

		logger.debug("lectura de configuración finalizada");
		Element security = null;
		try {
			ClientTimestampConfig config = new ClientTimestampConfig();
			config.setWsaTo(wsaTo);
			config.setWsaAction(wsaAction);
			config.setStsURL(stsURL);
			config.setStsIssuer(stsIssuer);
			config.setStsPolicyName(stsPolicyName);
					config.setStsRole(stsRole);
					config.setStsUserName(stsUserName);
					config.setSamlVersion(samlVersion);
					config.setCacheTokenEnabled(cacheTokenEnabled);
					config.setSoapVersion(soapVersion);
					config.setStsKeyStoreFilePath(stsKeyStoreFilePath);
					config.setStsKeyStorePass(stsKeyStorePass);
					config.setStsKeyStoreCertAlias(stsKeyStoreCertAlias);
					config.setSslTrustStoreFilePath(sslTrustStoreFilePath);
					config.setSslTrustStorePass(sslTrustStorePass);
					config.setMaxTotalOpenConnections(maxTotalOpenConnections);
					config.setMaxConnectionsPerRoute(maxConnectionsPerRoute);
					config.setMaxConnectionsHostnamePort(maxConnectionsHostnamePort);

			security = getWSSecuritySOAP(config);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		logger.debug("----------------Finalizando firma SOAP--------------");
		return security;
	}
	
	public Element getWSSecuritySOAP(ClientTimestampConfig clientTimeStampConfig) throws KeyStoreException, FileNotFoundException, RequestSecurityTokenException, KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, ConfigurationException {

		TrustManagerFactory trustManagerFactory = getTrustManagerFactory(clientTimeStampConfig.getSslTrustStoreFilePath(), clientTimeStampConfig.getSslTrustStorePass());

		KeyManagerFactory keyManagerFactory = getKeyManagerFactory(clientTimeStampConfig.getStsKeyStoreFilePath(), clientTimeStampConfig.getStsKeyStorePass());

		SSLContext sslContext = SSLContext.getInstance("TLS");
		sslContext.init(keyManagerFactory.getKeyManagers(), trustManagerFactory.getTrustManagers(), new SecureRandom());

		PGEClient client = new PGEClientCache(new PGEClientBasic());
		PGEConfig pgeConfig = new PGEConfig();

		// STS Config
		PGEConfig.STSConfig stsConfig = loadSTSConfig(clientTimeStampConfig);
		pgeConfig.setSTSConfig(stsConfig);

		// Keystore
		PGEConfig.KeyStore keyStore = loadKeyStoreConfig(clientTimeStampConfig.getStsKeyStoreFilePath(), clientTimeStampConfig.getStsKeyStorePass(), clientTimeStampConfig.getStsKeyStoreCertAlias(), clientTimeStampConfig.getSslTrustStoreFilePath(), clientTimeStampConfig.getSslTrustStorePass());
		pgeConfig.setKeyStore(keyStore);

		// SAML Config
		PGEConfig.SAMLConfig samlConfig = loadSAMLConfig(clientTimeStampConfig.getMaxTotalOpenConnections(), clientTimeStampConfig.getMaxConnectionsPerRoute(), clientTimeStampConfig.getMaxConnectionsHostnamePort());
		pgeConfig.setSAMLConfig(samlConfig);

		PGEConfiguration pgeConfiguration = new PGEConfiguration(pgeConfig);
		STSResponse stsResponse = client.requestSecurityToken(pgeConfiguration);
		Document d = convertStringToXMLDocument(WS_SECURED_HEADER_PART);
		if(d!=null) {
			Element header = d.getDocumentElement();
			header.getFirstChild().appendChild(d.importNode(stsResponse.getAssertion().getDOM(clientTimeStampConfig.getSamlVersion()), true));
			Document document = convertStringToXMLDocument(getWSAddressingToPart(clientTimeStampConfig.getWsaTo()));
			if (document != null) {
				Element documentElement = document.getDocumentElement();
				header.appendChild(d.importNode(documentElement, true));
				Document documentWsaAction = convertStringToXMLDocument(getWSAddressingActionPart(clientTimeStampConfig.getWsaAction()));
				if(documentWsaAction!=null) {
					header.appendChild(
							d.importNode(documentWsaAction.getDocumentElement(), true));
					logger.debug("soap assertion obtenido");
                    return d.getDocumentElement();
				}
			}
		}
		return null;
	}

	private static PGEConfig.STSConfig loadSTSConfig(ClientTimestampConfig config) {
		List<PGEConfig.STSConfig.Property> stsProperties = new ArrayList<>();
		PGEConfig.STSConfig.Property stsProperty;

		// Issuer
		stsProperty = new PGEConfig.STSConfig.Property();
		stsProperty.setKey(ConfigProperties.ISSUER);
		stsProperty.setValue(config.getStsIssuer());
		stsProperties.add(stsProperty);
		// Username
		stsProperty = new PGEConfig.STSConfig.Property();
		stsProperty.setKey(ConfigProperties.USERNAME);
		stsProperty.setValue(config.getStsUserName());
		stsProperties.add(stsProperty);
		// WSA To
		stsProperty = new PGEConfig.STSConfig.Property();
		stsProperty.setKey(ConfigProperties.WSA_TO);
		stsProperty.setValue(config.getWsaTo());
		stsProperties.add(stsProperty);
		// SAML version
		stsProperty = new PGEConfig.STSConfig.Property();
		stsProperty.setKey(ConfigProperties.SAML_VERSION);
		stsProperty.setValue(config.getSamlVersion()); // "1.1" | "2.0"
		stsProperties.add(stsProperty);
		// Cache token enabled
		stsProperty = new PGEConfig.STSConfig.Property();
		stsProperty.setKey(ConfigProperties.CACHE_TOKEN_ENABLED);
		stsProperty.setValue(config.getCacheTokenEnabled().booleanValue()?"1":"0"); // Yes: "1" | No: "0"
		stsProperties.add(stsProperty);
		// Role
		stsProperty = new PGEConfig.STSConfig.Property();
		stsProperty.setKey(ConfigProperties.ROLE);
		stsProperty.setValue(config.getStsRole());
		stsProperties.add(stsProperty);
		// SOAP version
		stsProperty = new PGEConfig.STSConfig.Property();
		stsProperty.setKey(ConfigProperties.SOAP_VERSION);
		stsProperty.setValue(config.getSoapVersion()); // "1.1" | "1.2" | "multiple"
		stsProperties.add(stsProperty);
		// Policy
		stsProperty = new PGEConfig.STSConfig.Property();
		stsProperty.setKey(ConfigProperties.POLICY);
		stsProperty.setValue(config.getStsPolicyName());
		stsProperties.add(stsProperty);

		PGEConfig.STSConfig stsConfig = new PGEConfig.STSConfig();
		// STS URL
		stsConfig.setUrl(config.getStsURL());
		stsConfig.setProperty(stsProperties);

		return stsConfig;
	}

	private static PGEConfig.KeyStore loadKeyStoreConfig(String stsKeyStoreFilePath, String stsKeyStorePass,
														 String stsKeyStoreCertAlias, String sslTrustStoreFilePath, String sslTrustStorePass) {
		List<PGEConfig.KeyStore.Auth> auths = new ArrayList<>();
		PGEConfig.KeyStore.Auth auth = new PGEConfig.KeyStore.Auth();

		// Alias
		auth.setKey(ConfigProperties.KEY_STORE_ALIAS);
		auth.setValue(stsKeyStoreCertAlias);
		auths.add(auth);
		// Keystore Org URL
		auth = new PGEConfig.KeyStore.Auth();
		auth.setKey(ConfigProperties.KEY_STORE_FILE_URL);
		auth.setValue(stsKeyStoreFilePath);
		auths.add(auth);
		// Keystore Org Pass
		auth = new PGEConfig.KeyStore.Auth();
		auth.setKey(ConfigProperties.KEY_STORE_PASS);
		auth.setValue(stsKeyStorePass);
		auths.add(auth);
		// SSL Keystore URL
		auth = new PGEConfig.KeyStore.Auth();
		auth.setKey(ConfigProperties.SSL_KEY_STORE_URL);
		auth.setValue(stsKeyStoreFilePath);
		auths.add(auth);
		// SSL Keystore Pass
		auth = new PGEConfig.KeyStore.Auth();
		auth.setKey(ConfigProperties.SSL_KEY_STORE_PASS);
		auth.setValue(stsKeyStorePass);
		auths.add(auth);
		// Truststore URL
		auth = new PGEConfig.KeyStore.Auth();
		auth.setKey(ConfigProperties.TRUST_STORE_URL);
		auth.setValue(sslTrustStoreFilePath);
		auths.add(auth);
		// Truststore Pass
		auth = new PGEConfig.KeyStore.Auth();
		auth.setKey(ConfigProperties.TRUST_STORE_PASS);
		auth.setValue(sslTrustStorePass);
		auths.add(auth);

		PGEConfig.KeyStore keyStore = new PGEConfig.KeyStore();
		keyStore.setAuth(auths);

		return keyStore;
	}

	private static PGEConfig.SAMLConfig loadSAMLConfig(Integer maxTotalOpenConnections, Integer maxConnectionsPerRoute,Integer maxConnectionsHostnamePort) {
		List<PGEConfig.SAMLConfig.Property> samlProperties = new ArrayList<>();
		PGEConfig.SAMLConfig.Property samlProperty;

		// PGE Client Config
		samlProperty = new PGEConfig.SAMLConfig.Property();
		samlProperty.setKey(ConfigProperties.SAML1_NAME_ID_FORMAT);
		samlProperty.setValue("urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress");
		samlProperties.add(samlProperty);

		samlProperty = new PGEConfig.SAMLConfig.Property();
		samlProperty.setKey(ConfigProperties.SAML1_CONFIRMATION_METHOD);
		samlProperty.setValue("urn:oasis:names:tc:SAML:1.0:cm:bearer");
		samlProperties.add(samlProperty);

		samlProperty = new PGEConfig.SAMLConfig.Property();
		samlProperty.setKey(ConfigProperties.SAML1_AUTHENTICATION_METHOD);
		samlProperty.setValue("urn:oasis:names:tc:SAML:1.0:am:password");
		samlProperties.add(samlProperty);

		samlProperty = new PGEConfig.SAMLConfig.Property();
		samlProperty.setKey(ConfigProperties.SAML2_NAME_ID_FORMAT);
		samlProperty.setValue("urn:oasis:names:tc:SAML:2.0:nameid-format:entity");
		samlProperties.add(samlProperty);

		samlProperty = new PGEConfig.SAMLConfig.Property();
		samlProperty.setKey(ConfigProperties.SAML2_CONFIRMATION_METHOD);
		samlProperty.setValue("urn:oasis:names:tc:SAML:2.0:cm:bearer");
		samlProperties.add(samlProperty);

		samlProperty = new PGEConfig.SAMLConfig.Property();
		samlProperty.setKey(ConfigProperties.SAML2_AUTHN_CONTEXT);
		samlProperty.setValue("urn:oasis:names:tc:SAML:2.0:ac:classes:X509");
		samlProperties.add(samlProperty);

		samlProperty = new PGEConfig.SAMLConfig.Property();
		samlProperty.setKey(ConfigProperties.SIGNATURE_ALGORITHM);
		samlProperty.setValue("http://www.w3.org/2000/09/xmldsig#rsa-sha1");
		samlProperties.add(samlProperty);

		samlProperty = new PGEConfig.SAMLConfig.Property();
		samlProperty.setKey(ConfigProperties.SIGNATURE_CANONICALIZATION_ALGORITHM);
		samlProperty.setValue("http://www.w3.org/2001/10/xml-exc-c14n#");
		samlProperties.add(samlProperty);

		// Connector Config
		samlProperty = new PGEConfig.SAMLConfig.Property();
		samlProperty.setKey(ConfigProperties.MAX_TOTAL_OPEN_CONNECTIONS);
		samlProperty.setValue(maxTotalOpenConnections.toString());
		samlProperties.add(samlProperty);

		samlProperty = new PGEConfig.SAMLConfig.Property();
		samlProperty.setKey(ConfigProperties.MAX_CONNECTIONS_PER_ROUTE);
		samlProperty.setValue(maxConnectionsPerRoute.toString());
		samlProperties.add(samlProperty);

		samlProperty = new PGEConfig.SAMLConfig.Property();
		samlProperty.setKey(ConfigProperties.MAX_CONNECTIONS_HOSTNAME_PORT);
		samlProperty.setValue(maxConnectionsHostnamePort.toString());
		samlProperties.add(samlProperty);

		PGEConfig.SAMLConfig samlConfig = new PGEConfig.SAMLConfig();
		samlConfig.setProperty(samlProperties);

		return samlConfig;
	}



	public static CloseableHttpClient getCloseableHttpClient(SSLContext sslContext) {

		SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(sslContext);
		Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder
				.<ConnectionSocketFactory>create()
				.register("https", sslSocketFactory)
			   .register("http", sslSocketFactory).build();

		HttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
		((PoolingHttpClientConnectionManager)connManager).setMaxTotal(200);
		((PoolingHttpClientConnectionManager)connManager).setDefaultMaxPerRoute(60);


		Integer timeout=120000;
			SocketConfig sc = SocketConfig.custom()
					.setSoTimeout(timeout)
					.setSoReuseAddress(true)
					.setTcpNoDelay(true)
					.setSoReuseAddress(true)
					.setSoKeepAlive(true)
					.build();
		((PoolingHttpClientConnectionManager)connManager).setDefaultSocketConfig(sc);


		RequestConfig.Builder requestBuilder = RequestConfig.custom();
		requestBuilder.setConnectTimeout(timeout);
		requestBuilder.setConnectionRequestTimeout(timeout);
		requestBuilder.setSocketTimeout(timeout);

		HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
		httpClientBuilder.setDefaultRequestConfig(requestBuilder.build());

		return httpClientBuilder.setConnectionManager(connManager).setConnectionManagerShared(true).build();
	}

	public KeyManagerFactory getKeyManagerFactory(String sslClientKeyStoreFilePath, String sslClientKeyStorePass)
			throws NoSuchAlgorithmException, KeyStoreException, UnrecoverableKeyException, FileNotFoundException {

		KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
		try (FileInputStream instream = new FileInputStream(new File(sslClientKeyStoreFilePath))){
			keyStore.load(instream, sslClientKeyStorePass.toCharArray());
		} catch (NoSuchAlgorithmException | CertificateException | IOException e) {
			logger.error(e.getMessage());
		}
		KeyManagerFactory keyManagerFactory = null;

		keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
		keyManagerFactory.init(keyStore, sslClientKeyStorePass.toCharArray());
		return keyManagerFactory;
	}

	public TrustManagerFactory getTrustManagerFactory(String sslTrustStoreFilePath, String sslTrustStorePass)
			throws KeyStoreException, FileNotFoundException, NoSuchAlgorithmException {
		FileInputStream instream;
		KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
		instream = new FileInputStream(new File(sslTrustStoreFilePath));
		try {
			trustStore.load(instream, sslTrustStorePass.toCharArray());
		} catch (NoSuchAlgorithmException | CertificateException | IOException e) {
			logger.error(e.getMessage());
		} finally {
			try {
				instream.close();
			} catch (Exception ignore) {
				logger.error(ignore.getMessage());
			}
		}

		TrustManagerFactory trustManagerFactory = null;
		trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
		trustManagerFactory.init(trustStore);
		return trustManagerFactory;
	}

	public static Document convertStringToXMLDocument(String xmlString) 
    {
        //Parser that produces DOM object trees from XML content
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setExpandEntityReferences(false);
        //API to obtain DOM Document instance
        DocumentBuilder builder = null;
        try
        {
            builder = factory.newDocumentBuilder();

            return builder.parse(new InputSource(new StringReader(xmlString)));
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        return null;
    }


	public String getWSAddressingToPart(String to){
		return String.format(WS_ADDRESSING_TO_PART_FORMAT, to);

	}
	
	public String getWSAddressingActionPart(String action){
		return String.format(WS_ADDRESSING_ACTION_PART_FORMAT,action);

	}

}